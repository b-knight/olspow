"""olspowPackage."""

from olspow import solve_power

__version__ = "1.0.0"
