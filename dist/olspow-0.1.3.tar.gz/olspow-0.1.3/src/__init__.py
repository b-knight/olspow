"""olspowPackage."""

from olspow import solve_power

__version__ = "0.1.3"
